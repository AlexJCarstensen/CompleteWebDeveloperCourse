<?php

$link= mysqli_connect("localhost", "mySql USER NAME", "mySql Password ", "mySql Database name");


?>